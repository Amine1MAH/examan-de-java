public class Etudiant {
    private String nom;
    private int age;
    private String cours;

    // Constructeur
    public Etudiant(String nom, int age, String cours) {
        this.nom = nom;
        this.age = age;
        this.cours = cours;
    }

    // Getters
    public String getNom() {
        return nom;
    }

    public int getAge() {
        return age;
    }

    public String getCours() {
        return cours;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setCours(String cours) {
        this.cours = cours;
    }
}
