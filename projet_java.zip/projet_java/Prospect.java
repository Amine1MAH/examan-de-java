public class Prospect {
    private String nom;
    private String email;
    private String programmeInteresse;

    // Constructeur
    public Prospect(String nom, String email, String programmeInteresse) {
        this.nom = nom;
        this.email = email;
        this.programmeInteresse = programmeInteresse;
    }

    // Getters
    public String getNom() {
        return nom;
    }

    public String getEmail() {
        return email;
    }

    public String getProgrammeInteresse() {
        return programmeInteresse;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setProgrammeInteresse(String programmeInteresse) {
        this.programmeInteresse = programmeInteresse;
    }
}
