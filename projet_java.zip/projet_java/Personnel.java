public class Personnel {
    private String nom;
    private String poste;
    private int experience;

    // Constructeur
    public Personnel(String nom, String poste, int experience) {
        this.nom = nom;
        this.poste = poste;
        this.experience = experience;
    }

    // Getters
    public String getNom() {
        return nom;
    }

    public String getPoste() {
        return poste;
    }

    public int getExperience() {
        return experience;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }
}
