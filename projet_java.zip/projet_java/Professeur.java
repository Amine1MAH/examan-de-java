public class Professeur {
    private String nom;
    private String matiere;
    private int experience;

    // Constructeur
    public Professeur(String nom, String matiere, int experience) {
        this.nom = nom;
        this.matiere = matiere;
        this.experience = experience;
    }

    // Getters
    public String getNom() {
        return nom;
    }

    public String getMatiere() {
        return matiere;
    }

    public int getExperience() {
        return experience;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setMatiere(String matiere) {
        this.matiere = matiere;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }
}
