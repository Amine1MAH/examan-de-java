public class Directeur {
    private String nom;
    private String departement;
    private int experience;

    // Constructeur
    public Directeur(String nom, String departement, int experience) {
        this.nom = nom;
        this.departement = departement;
        this.experience = experience;
    }

    // Getters
    public String getNom() {
        return nom;
    }

    public String getDepartement() {
        return departement;
    }

    public int getExperience() {
        return experience;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }
}
