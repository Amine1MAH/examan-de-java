public class Main {
    public static void main(String[] args) {
        // Créer des instances pour chaque classe
        Etudiant etudiant1 = new Etudiant("Paul", "Dupont", 21);
        Professeur professeur1 = new Professeur("Marie", "Martin", "Mathématiques");
        Prospect prospect1 = new Prospect("Lucas", "lucas@gmail.com", "Informatique");
        Personnel personnel1 = new Personnel("Sophie", "Secrétaire", 5);

        // Utiliser les getters pour afficher les informations des instances
        System.out.println("Etudiant : " + etudiant1.getNom() + " " + etudiant1.getPrenom() + ", " + etudiant1.getAge() + " ans");
        System.out.println("Professeur : " + professeur1.getNom() + " " + professeur1.getPrenom() + ", enseigne : " + professeur1.getMatiere());
        System.out.println("Prospect : " + prospect1.getNom() + ", email : " + prospect1.getEmail() + ", programme d'intérêt : " + prospect1.getProgrammeInteresse());
        System.out.println("Personnel : " + personnel1.getNom() + ", poste : " + personnel1.getPoste() + ", expérience : " + personnel1.getExperience() + " ans");
    }
}
